function start() {
    
	var pos, $id = function(d) { return document.getElementById(d);};
	
    
	var tierra = new PhiloGL.O3D.Sphere(
		{
            nlant: 30,
            nlong: 30,
            radius: 2,
            textures: 'images/earth.jpg'
        }
    );
    
    PhiloGL('glCanvas', {
        camera:{ 
            position:{  
                x:0,y:0,z:-15 
            } 
        },
        textures: {
            src:['images/earth.jpg'],
            parameters:[{					
					name:'TEXTURE_MAG_FILTER',
					value:'LINEAR'
            },
			{
                name:'TEXTURE_MIN_FILTER',
				value:'LINEAR_MIPMAP_NEAREST',
				generateMipmap:true
            }]
        }, 
        
        onLoad: function(app) {
            var gl=app.gl,
                programa = app.program,
				scene = app.scene,
				canvas = app.canvas,
				camera=app.camera;
            
            gl.clearColor(0.0, 0.0, 0.0, 1.0);
            gl.clearDepth(1.0);
			gl.enable(gl.DEPTH_TEST);
			gl.depthFunc(gl.LEQUAL);
			gl.viewport(0,0,+canvas.width,+canvas.height);
				
			tierra.rotation.x=3.15;
			tierra.rotation.y=0.3;
			tierra.update();
			scene.add(tierra);
			draw();
            
            function draw(){
                gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPHT_BUFFER_BIT);
                scene.render();
                PhiloGL.Fx.requestAnimationFrame(draw);	
            }
        }
    });
}